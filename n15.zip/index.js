var fs = require('fs'), path = require('path');
console.log('Loading event');

var runner = require('pipes2js').run;

exports.handler = function(event, context) {

    //context.done(null, JSON.stringify(event, null, 3) + '\n' + JSON.stringify(context, null, 3));
    var deciderCode = fs.readFileSync(path.join(__dirname + '/converted/', event['_id'] + '.js'), 'utf8');
    runner({}, deciderCode, function (err, results, state) {
      // result = context.done(null, JSON.stringify(results, null, 3));
      result = context.done(null, results);
    });
};
